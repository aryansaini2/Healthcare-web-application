# eHealth medical-web-app

This is a medical web application built with Django framework. I was given this as a test task to prove my eligibility for python web developer job in Nigeria.

This web application registers two types of users: 

- The free account registers regular users which would be given to medical form of diseases they have experienced to input data to the database. After that, the information of all the regular users would be analized and displayed in charts on their homepage.

- The medical practitioner account registers medical practitioners to view and access all the information of all the regular users registered on the database. On their home, they have access to the charts, dropdown to filter all the regular users by their names based on the medical records and also all the information of every individual regular user in a table format.


This web application is deployed to a heroku server and running on free dynos. To view this project in real time, here is the url :
        https://ehealth4everyone.herokuapp.com
        
Thank you
